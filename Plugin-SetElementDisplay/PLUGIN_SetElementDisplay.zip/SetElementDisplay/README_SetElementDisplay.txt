-----------------------------DISCLAIMER-----------------------------
This script is not an official component of the RedDot Content 
Management Server, and is not supported or guaranteed by RedDot 
Solutions Corporation.  All claims of functionality are made by the 
script's author, and are not guaranteed by RedDot (regardless of any 
affiliation the author might have with RedDot Solutions). 

               **TEST FULLY AND USE AT YOR OWN RISK**
** THIS SCRIPT IS PROVIDED FREE OF CHARGE, AND MAY NOT BE RESOLD **

--------------------------------------------------------------------

Plugin:  Set Element Display (hide in project structure)

Version: 6.0

Date: June 9, 2006

Compatibility:  CMS 6.x +

Author: Jason Grollman (jason.grollman@reddot.com)

Description:

This a plugin to set the display status of the non-hideable elements.  It just sets the "eltinvisibleinclient" attribute, which seems to work even if that isn't an available attribute in the element settings.

Installation:

Copy the attached XML file and ASP file{s} directly to the CMS "PlugIns" 
directory.  Import the plugin via the Server Manager using the provided 
XML file, then activate and assign it to your project(s) using the normal 
plugin installation procedure (see Server Manger documentation for 
details).

Usage:  

In the Smart Tree, select an element of a content class that does not normally have the option to "Hide in project structure" (e.g. container).  From the Action Menu select the option "Set Element Display in Project Structure" and use the dialog to toggle the elements display mode.

