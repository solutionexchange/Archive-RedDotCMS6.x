-----------------------------DISCLAIMER-----------------------------
This script is not an official component of the RedDot Content 
Management Server, and is not supported or guaranteed by RedDot 
Solutions Corporation.  All claims of functionality are made by the 
script's author, and are not guaranteed by RedDot (regardless of any 
affiliation the author might have with RedDot Solutions). 

               **TEST FULLY AND USE AT YOR OWN RISK**
** THIS SCRIPT IS PROVIDED FREE OF CHARGE, AND MAY NOT BE RESOLD **

--------------------------------------------------------------------

Plugin:  Change Creation Date of Page

Version: 6.0

Date: May 5, 2006

Compatibility:  CMS 6.x +

Author: Michael Madden (Michael.madden@reddot.com), Hilmar Bunjes

Description:

This plugins allows you to change the creation date of a page.

Installation:

Copy the attached XML file and ASP file{s} directly to the CMS "PlugIns" 
directory.  Import the plugin via the Server Manager using the provided 
XML file, then activate and assign it to your project(s) using the normal 
plugin installation procedure (see Server Manger documentation for 
details).

In the script file the user credentials for the SQL server must be entered
at the top.

Usage:  

Click on a page in SmartTree and in the Action Menu there is a link called
"Change Creation Date of Page". Just click on that link and you can change 
the date and time the page was created on.

Notes:

If you want to see the date of creation by clicking the information button
on the upper right corner you have to deselect the page and select it again.
Otherwise you will get the old information.