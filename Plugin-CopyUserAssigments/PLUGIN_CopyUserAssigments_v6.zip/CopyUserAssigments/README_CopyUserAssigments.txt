-----------------------------DISCLAIMER-----------------------------
This script is not an official component of the RedDot Content 
Management Server, and is not supported or guaranteed by RedDot 
Solutions Corporation.  All claims of functionality are made by the 
script's author, and are not guaranteed by RedDot (regardless of any 
affiliation the author might have with RedDot Solutions). 

               **TEST FULLY AND USE AT YOR OWN RISK**
** THIS SCRIPT IS PROVIDED FREE OF CHARGE, AND MAY NOT BE RESOLD **

--------------------------------------------------------------------

Plugin:  Copy user assignments to another project

Version: 6.0

Date: May 8, 2006

Compatibility:  CMS 6.x +

Author: Michael Madden (Michael.madden@reddot.com)

Description:

This plugin copies group and user assignments from one project to another. 
The user roles in the project (Admin, Editor, ...) are copied as well.

Installation:

Copy the attached XML file and ASP file{s} directly to the CMS "PlugIns" 
directory.  Import the plugin via the Server Manager using the provided 
XML file (see Server Manger documentation for details). 

Usage:  

In the Server Manager open the tree segment "Administer Users and Groups".
Either click on Users or Groups and in the Action Menu and in the Action 
Menu there is a new option "Copy user assignments to another project".

In the pop-up window you can first select the project to copy the assignments
from and afterwards the project to copy the assignments to. Afterwards
there will be an overview of the copied users, groups and assignements.

Notes:


