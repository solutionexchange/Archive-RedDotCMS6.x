-----------------------------DISCLAIMER-----------------------------
This script is not an official component of the RedDot Content 
Management Server, and is not supported or guaranteed by RedDot 
Solutions Corporation.  All claims of functionality are made by the 
script's author, and are not guaranteed by RedDot (regardless of any 
affiliation the author might have with RedDot Solutions). 

               **TEST FULLY AND USE AT YOR OWN RISK**
** THIS SCRIPT IS PROVIDED FREE OF CHARGE, AND MAY NOT BE RESOLD **

--------------------------------------------------------------------

Plugin: Rename Headlines

Version: 6.0

Date: May 25, 2006

Compatibility:  CMS 6.x +

Author: unknown, adjusted to CMS 6.x by Hilmar Bunjes

Description:

This plugin renames headlines of all pages. This is especially useful to get
rid of the "Copy of" in front of page names.

Installation:

Copy the attached XML file and ASP file{s} directly to the CMS "PlugIns" 
directory.  Import the plugin via the Server Manager using the provided 
XML file (see Server Manger documentation for details). 

Usage:  

Click on a link of a tree segment you want to edit. In the action menu you can choose 
"Rename Headlines" and in the pop-up window you can change the country code of the
page as well as a prefix that will be deleted on the page connected to the link as well
pages in the sub tree.

Notes:

The script will end renaming pages in one part of a sub tree as soon as one page
doesn't have the prefix you specified. That doesn't not mean that the script ends here
but only renaming pages in the tree segment below the page which doesn't have the prefix.
