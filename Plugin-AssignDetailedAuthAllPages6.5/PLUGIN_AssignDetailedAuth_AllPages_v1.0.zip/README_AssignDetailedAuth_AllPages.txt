-----------------------------DISCLAIMER-----------------------------
This script is not an official component of the RedDot Content 
Management Server, and is not supported or guaranteed by RedDot 
Solutions Corporation.  All claims of functionality are made by the 
script's author, and are not guaranteed by RedDot (regardless of any 
affiliation the author might have with RedDot Solutions). 

               **TEST FULLY AND USE AT YOR OWN RISK**
** THIS SCRIPT IS PROVIDED FREE OF CHARGE, AND MAY NOT BE RESOLD **

--------------------------------------------------------------------

Plugin:  Assign Detailed Authorizations to All Element Instances

Version: 6.5

Date: May 5, 2006

Compatibility:  Tested with 6.5.  May be compatible with earlier 6.x versions.

Author: Michael Madden (Michael.madden@reddot.com)

Description:

This plugin may be used to retroactively assign a detailed authorization
package to all existing instances of a content or structure element.  It
is similar to assigning a detailed package to an element instance, but it
is applied to all instances of the element (i.e. to the same element in all
existing pages that are based on the same content class).  It is generally
recommended that you independently pre-assign the detailed authorization to
the corresponding content-class element, in order to apply it to all future
pages; the plugin does not do this for you.

Installation:

Copy the attached XML file and ASP files directly to the CMS "PlugIns" 
directory.  Import the plugin via the Server Manager using the provided 
XML file, then activate and assign it to your project(s) using the normal 
plugin installation procedure (see Server Manger documentation for 
details).

Usage:  

In SmartTree, select any instance of the link or element in any existing
page, then click the action "Assign Detailed Authorization in Clipboard to 
all Element Instances" at the bottom of the Action Menu.  If there are a
large number of instances, the plugin may take some time to finish.  Please
keep the window open until it is complete.

