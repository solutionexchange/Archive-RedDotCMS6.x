-----------------------------DISCLAIMER-----------------------------
This script is not an official component of the RedDot Content 
Management Server, and is not supported or guaranteed by RedDot 
Solutions Corporation.  All claims of functionality are made by the 
script's author, and are not guaranteed by RedDot (regardless of any 
affiliation the author might have with RedDot Solutions). 

               **TEST FULLY AND USE AT YOR OWN RISK**
** THIS SCRIPT IS PROVIDED FREE OF CHARGE, AND MAY NOT BE RESOLD **

--------------------------------------------------------------------

Plugin:  Set all Content Classes instances as Site Map pages

Version: 6.0

Date: June 9, 2006

Compatibility:  CMS 6.x +

Author: Michael Madden (Michael.madden@reddot.com)

Description:

Plugin that sets all instances of a selected content class as site map pages.  The main link is used as the Site Map link.

Installation:

Copy the attached XML file and ASP file{s} directly to the CMS "PlugIns" 
directory.  Import the plugin via the Server Manager using the provided 
XML file, then activate and assign it to your project(s) using the normal 
plugin installation procedure (see Server Manger documentation for 
details).

Usage:  

In the Smart Tree, select a content class.  Choose the option in the Action Menu named "Set All Instances as Site Map Pages."  All pages made with that content class will now be site map pages (normally set for a page via the "Define Site Map Link" option in the Action Menu).

Notes:

 + If you recieve the error message "Error: Access is Denied." when attempting to run the plugin, take the following to resolve the problem:
   1) Navigate to the CMS plugins folder (e.g. C:\Program Files\RedDot\CMS\ASP\PlugIns)
   2) Locate the file "SetAllPages4Sitemap.asp" and right-click it.  From the pop up menu choose "Properties".
   3) Select the "Security" tab.
   4) Ensure that the check box labeled "Allow inheritable permissions from parent to propagate to this object" is checked.