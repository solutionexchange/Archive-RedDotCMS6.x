-----------------------------DISCLAIMER-----------------------------
This script is not an official component of the RedDot Content 
Management Server, and is not supported or guaranteed by RedDot 
Solutions Corporation.  All claims of functionality are made by the 
script's author, and are not guaranteed by RedDot (regardless of any 
affiliation the author might have with RedDot Solutions). 

               **TEST FULLY AND USE AT YOR OWN RISK**
** THIS SCRIPT IS PROVIDED FREE OF CHARGE, AND MAY NOT BE RESOLD **

--------------------------------------------------------------------

Plugin:  Set Element Description

Version: 6.0

Date: June 9, 2006

Compatibility:  CMS 6.x +

Author: Michael Madden (michael.madden@reddot.com)

Description:

This plugin can be used to set a description for certain element types, e.g. Transfer, which do not normally have that option.  Besides Transfer, it also supports Background, Database Content, LiveServer Contstraint, Project Content, XCMS Project Content, Area, Container, Frame, Hit List, List, Site Map, Attribute, and Info.  It simply sets the "eltrddescription" attribute for the element.

Installation:

Copy the attached XML file and ASP file{s} directly to the CMS "PlugIns" 
directory.  Import the plugin via the Server Manager using the provided 
XML file, then activate and assign it to your project(s) using the normal 
plugin installation procedure (see Server Manger documentation for 
details).

Usage:  

In the Smart Tree, select an element of a content class that is handled by this plugin (e.g. container).  In the Action Menu there is a new option called "Set Element Description" which will allow the user to set a description for the element.

